package com.capg.service;

import com.capg.bean.ThirdPartyMerchant;

public interface IThirdPartyMerchantService {

	public void addThirdPartyMerchant(ThirdPartyMerchant bean) throws Exception;
}
