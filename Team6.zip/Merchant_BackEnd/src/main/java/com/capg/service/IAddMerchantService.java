package com.capg.service;

import com.capg.bean.AddMerchantBean;

public interface IAddMerchantService {
	public void addMerchant(AddMerchantBean addDataBean);
	public void deleteMerchant(String merchant_Email);
	public boolean findMerchant(String merchant_Email);
}
