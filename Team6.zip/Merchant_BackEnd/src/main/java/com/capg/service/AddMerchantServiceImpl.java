package com.capg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.bean.AddMerchantBean;
import com.capg.repo.IAddMerchatRepo;
@Service
public class AddMerchantServiceImpl implements IAddMerchantService {
	@Autowired
	private IAddMerchatRepo addDataRepo;

	@Override
	public void addMerchant(AddMerchantBean addDataBean) {
		addDataRepo.save(addDataBean);
	}

	@Override
	public void deleteMerchant(String merchant_Email) {
		addDataRepo.deleteById(merchant_Email);
	}

	@Override
	public boolean findMerchant(String merchant_Email) {
		boolean res = false;
		if (addDataRepo.findById(merchant_Email).get() != null) {
			res = true;
		} else
			res = false;
		return res;
	}
}
