package com.capg.service;

public interface ILoginService {
	public boolean check(String username, String password);

}
