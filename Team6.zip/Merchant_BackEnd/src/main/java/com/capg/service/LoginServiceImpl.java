package com.capg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.bean.LoginBeans;
import com.capg.repo.ILoginRepo;

@Service
public class LoginServiceImpl implements ILoginService {

	@Autowired
	ILoginRepo repo;

	@Override
	public boolean check(String username, String password) {
		LoginBeans bean = repo.findById(username).get();
		if (bean.getPassword().equals(password)) {
			return true;
		} else
			return false;
	}

}
