package com.capg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.bean.ThirdPartyMerchant;
import com.capg.repo.IAddThirdPartyMerchantRepo;

@Service
public class ThirdPartyMerchantServiceImpl implements IThirdPartyMerchantService {

	@Autowired
	private IAddThirdPartyMerchantRepo repo;

	@Override
	public void addThirdPartyMerchant(ThirdPartyMerchant thirdPartyMerchant) throws Exception{
		try {
			repo.save(thirdPartyMerchant);
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
