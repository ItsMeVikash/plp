package com.capg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capg.bean.AddMerchantBean;
import com.capg.bean.AddProduct;
import com.capg.bean.ThirdPartyMerchant;
import com.capg.service.IAddMerchantService;
import com.capg.service.ILoginService;
import com.capg.service.IMerchantService;
import com.capg.service.IThirdPartyMerchantService;

@RestController
public class BackEndController {

	@Autowired
	IMerchantService service;
	@Autowired
	ILoginService loginService;
	@Autowired
	IAddMerchantService merchantService;
	@Autowired
	IThirdPartyMerchantService thirdMerchantService;

	@RequestMapping(value = "/addpro")
	boolean addProduct(@RequestBody AddProduct product) {
		boolean res = false;
		boolean b = service.addProduct(product);
		if (b) {
			res = true;
		}
		return res;
	}

	@RequestMapping(value = "/login{username}{password}")
	public String login(@RequestParam String username, @RequestParam String password) throws Exception {
		boolean b = false;
		String str = null;
		try {
			b = loginService.check(username, password);
			if (b) {
				str = "success";

			}
		} catch (Exception e) {
			str = "failure";
		}
		return str;
	}

	@RequestMapping(value = "/remove{productId}{productName}{Quantity}", method = RequestMethod.PUT)
	public void removeProduct(@RequestParam String productId, @RequestParam String productName,
			@RequestParam String Quantity) throws Exception {
		service.removeProduct(productId, productName, Quantity);

	}

	@RequestMapping(value = "/product{productId}{Quantity}")
	public String searchProduct(@RequestParam String productId, @RequestParam String Quantity) throws Exception {
		String str;
		String res = service.searchProduct(productId, Quantity);
		if (res.equals("updated")) {
			str = "updated";
		} else if (res.equals("deleted")) {
			str = "deleted";
		} else if (res.equals("notUpdated")) {
			str = "notUpdated";
		} else {
			str = "notFound";
		}
		return str;

	}

	// vikash Module 13
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String addPerson(@RequestBody AddMerchantBean bean) {
		merchantService.addMerchant(bean);
		return "added";
	}

	@RequestMapping(value = "/delete{merchant_Email}", method = RequestMethod.DELETE)
	public String deletePerson(@RequestParam String merchant_Email) {
		merchantService.deleteMerchant(merchant_Email);
		return "deleted";
	}

	@RequestMapping(value = "/find{merchant_Email}", method = RequestMethod.GET)
	public String findPerson(@RequestParam String merchant_Email) throws Exception {
		boolean b = false;
		String str = null;
		try {
			b = merchantService.findMerchant(merchant_Email);
			if (b) {
				str = "found";
			}
		} catch (Exception e) {
			return "notfound";
		}

		return str;

	}

	// shivani Module 14
	@RequestMapping(value = "/addMerchant", method = RequestMethod.POST)
	public String addThirdPartyMerchant(@RequestBody ThirdPartyMerchant thirdPartyMerchant) throws Exception {
		thirdMerchantService.addThirdPartyMerchant(thirdPartyMerchant);
		return "added";
	}

}