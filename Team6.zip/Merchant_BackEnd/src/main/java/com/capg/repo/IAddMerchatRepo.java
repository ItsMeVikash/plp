package com.capg.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capg.bean.AddMerchantBean;



@Repository
public interface IAddMerchatRepo extends CrudRepository<AddMerchantBean, String> {

}
