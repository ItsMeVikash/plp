package com.capg.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capg.bean.LoginBeans;

@Repository
public interface ILoginRepo extends CrudRepository<LoginBeans, String> {

}
