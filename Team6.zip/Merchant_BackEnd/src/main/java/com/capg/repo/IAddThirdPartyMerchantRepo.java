package com.capg.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capg.bean.ThirdPartyMerchant;

@Repository
public interface IAddThirdPartyMerchantRepo extends CrudRepository<ThirdPartyMerchant, String>{

}
