package com.capg.beans;

public class AddMerchantBean {

	private String merchant_Email;
	private String merchant_Name;
	private String merchant_Mobile;
	private String merchant_Category;
	private String merchant_Location;
	private String merchant_accountNumber;
	private String merchant_IfscCode;

	public AddMerchantBean() {
	}

	public AddMerchantBean(String merchant_Email, String merchant_Name, String merchant_Mobile,
			String merchant_Category, String merchant_Location, String merchant_accountNumber,
			String merchant_IfscCode) {
		super();
		this.merchant_Email = merchant_Email;
		this.merchant_Name = merchant_Name;
		this.merchant_Mobile = merchant_Mobile;
		this.merchant_Category = merchant_Category;
		this.merchant_Location = merchant_Location;
		this.merchant_accountNumber = merchant_accountNumber;
		this.merchant_IfscCode = merchant_IfscCode;
	}

	public String getMerchant_Email() {
		return merchant_Email;
	}

	public void setMerchant_Email(String merchant_Email) {
		this.merchant_Email = merchant_Email;
	}

	public String getMerchant_Name() {
		return merchant_Name;
	}

	public void setMerchant_Name(String merchant_Name) {
		this.merchant_Name = merchant_Name;
	}

	public String getMerchant_Mobile() {
		return merchant_Mobile;
	}

	public void setMerchant_Mobile(String merchant_Mobile) {
		this.merchant_Mobile = merchant_Mobile;
	}

	public String getMerchant_Category() {
		return merchant_Category;
	}

	public void setMerchant_Category(String merchant_Category) {
		this.merchant_Category = merchant_Category;
	}

	public String getMerchant_Location() {
		return merchant_Location;
	}

	public void setMerchant_Location(String merchant_Location) {
		this.merchant_Location = merchant_Location;
	}

	public String getMerchant_accountNumber() {
		return merchant_accountNumber;
	}

	public void setMerchant_accountNumber(String merchant_accountNumber) {
		this.merchant_accountNumber = merchant_accountNumber;
	}

	public String getMerchant_IfscCode() {
		return merchant_IfscCode;
	}

	public void setMerchant_IfscCode(String merchant_IfscCode) {
		this.merchant_IfscCode = merchant_IfscCode;
	}

}
