package com.capg.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.capg.beans.AddMerchantBean;
import com.capg.beans.AddProduct;
import com.capg.beans.ThirdPartyMerchant;

@Controller
public class FrontController {

	@RequestMapping("/addpro")
	public ModelAndView addProduct(AddProduct product) {

		RestTemplate rest = new RestTemplate();
		System.out.println(product.getProductId());
		String url = "http://localhost:9092/addpro";
		boolean abc = rest.postForObject(url, product, Boolean.class);
		if (abc) {
			return new ModelAndView("successAddProduct");
		} else
			return new ModelAndView("failureAddProduct");
	}

	@RequestMapping("/remove")
	public ModelAndView removeProduct(String productId, String productName, String Quantity) {
		RestTemplate rest = new RestTemplate();
		String res = rest.getForObject("http://localhost:9092/product?productId=" + productId + "&Quantity=" + Quantity,
				String.class);
		if (res.equals("updated")) {
			rest.put("http://localhost:9092/remove?productId=" + productId + "&productName=" + productName
					+ "&Quantity=" + Quantity, String.class);
			return new ModelAndView("RemoveSuccess", "result", res);
		} else if (res.equals("deleted")) {
			rest.put("http://localhost:9092/remove?productId=" + productId + "&productName=" + productName
					+ "&Quantity=" + Quantity, String.class);
			return new ModelAndView("RemoveSuccess", "result", res);
		} else if (res.equals("notUpdated")) {
			return new ModelAndView("RemoveSuccess", "result", res);
		} else {
			return new ModelAndView("RemoveSuccessS", "result", res);
		}
	}

	@RequestMapping("/login")
	public ModelAndView checkAdminLogin(String username, String password) throws Exception {
		RestTemplate restTemplate = new RestTemplate();
		try {
			String status = restTemplate.getForObject(
					"http://localhost:9092/login?username=" + username + "&password=" + password, String.class);
			if (status.equals("success")) {
				return new ModelAndView("home", "merchant", status);
			} else {
				return new ModelAndView("relogin", "merchant", status);
			}
		} catch (Exception e) {
			return new ModelAndView("relogin");
		}

	}

	// vikash Module 13
	@RequestMapping(value = "/add")
	public ModelAndView addMerchant(AddMerchantBean bean) {
		final String uri = "http://localhost:9092/add";
		RestTemplate restTemplate = new RestTemplate();
		String result = restTemplate.postForObject(uri, bean, String.class);
		if (result.equals("added")) {
			return new ModelAndView("successAddMerchant");

		} else {
			return new ModelAndView("failureAddMerchant");
		}

	}

	@RequestMapping(value = "/delete")
	public ModelAndView deleteMerchant(@RequestParam String merchant_Email) {
		RestTemplate restTemplate = new RestTemplate();
		String str = restTemplate.getForObject("http://localhost:9092/find?merchant_Email=" + merchant_Email,
				String.class);
		if (str.equals("found")) {
			restTemplate.delete("http://localhost:9092/delete?merchant_Email=" + merchant_Email);
			return new ModelAndView("successDeleteMerchant");

		} else {
			return new ModelAndView("failureDeleteMerchant");
		}

	}

	// shivani Module 14
	@RequestMapping("/addMerchant")
	public ModelAndView addMerchant(ThirdPartyMerchant thirdPartyMerchant) throws Exception {
		RestTemplate restTemplateNew = new RestTemplate();
		final String uri = "http://localhost:9092/addMerchant";
		try {
			String value = restTemplateNew.postForObject(uri, thirdPartyMerchant, String.class);
			if (value.equals("added")) {
				return new ModelAndView("successAddThirdParty");
			} else {
				return new ModelAndView("failureAddThirdParty");
			}
		} catch (Exception e) {
			return new ModelAndView("failureAddThirdParty");
		}
	}
}
