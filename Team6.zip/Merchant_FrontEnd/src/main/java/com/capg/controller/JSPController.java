package com.capg.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class JSPController {
	
	@RequestMapping(value="/homepage", method=RequestMethod.GET)
	public String updateM()
	{
		return "home";
	}
	@RequestMapping(value="/merchant", method=RequestMethod.GET)
	public String MoveToMerchant()
	{
		return "merchant";
	}
	@RequestMapping(value="/thirdParty", method=RequestMethod.GET)
	public String MoveToThirdPartyMerchant()
	{
		return "thirdParty";
	}
	
	@RequestMapping(value="/products", method=RequestMethod.GET)
	public String MoveToTProductManagement()
	{
		return "product";
	}

}
